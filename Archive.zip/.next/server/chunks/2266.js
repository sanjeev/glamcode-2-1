exports.id = 2266;
exports.ids = [2266,5044,6746,699];
exports.modules = {

/***/ 7969:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ LoginModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _services_front_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1150);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_actions_index__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6051);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, react_toastify__WEBPACK_IMPORTED_MODULE_4__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, react_toastify__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function LoginModal(props) {
    const { show , handleClose  } = props;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const { pathname  } = (next_router__WEBPACK_IMPORTED_MODULE_6___default());
    const [mainOtp, setMainotp] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [dataMb, setDataMb] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    const [sending, setSending] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const { register , handleSubmit , formState: { errors  } , reset , trigger  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)(); // initialize the hook
    const onSubmit = (data)=>{
        setSending(true);
        _services_front_services__WEBPACK_IMPORTED_MODULE_3__/* .frontService.sendOtpcode */ .Z.sendOtpcode(data).then((res)=>{
            if (res.status == "success") {
                localStorage.setItem("phonenumber", data.phone);
                setMainotp(true);
                reset();
                setDataMb(res.mb);
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(res.message, {
                    position: "bottom-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            } else if (res.status == "fail") {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(res.message, {
                    position: "bottom-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            } else {
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)("Invalid", {
                    position: "bottom-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
            }
            setSending(false);
        }, (error)=>{
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)("Invalid", {
                position: "bottom-center",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light"
            });
            setSending(false);
        });
    };
    const onOtp = (data)=>{
        //console.log(dataMb.otp)
        //console.log(data.otp);
        setSending(true);
        if (parseInt(data.otp) === parseInt(dataMb.otp)) {
            const dat = {
                "mobile": dataMb.mobile
            };
            _services_front_services__WEBPACK_IMPORTED_MODULE_3__/* .frontService.sendOtpverify */ .Z.sendOtpverify(dat).then((res)=>{
                if (res.status === "success") {
                    console.log(res.user);
                    localStorage.setItem("gluserDetails", JSON.stringify(res.user));
                    dispatch((0,_store_actions_index__WEBPACK_IMPORTED_MODULE_9__/* .userData */ .ZW)(res.user));
                    reset();
                    (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(res.message, {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light"
                    });
                    window.location.reload();
                // Router.push('/checkout')
                } else if (res.status === "fail") {
                    (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)(res.message, {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light"
                    });
                } else {
                    (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)("Invalid", {
                        position: "bottom-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light"
                    });
                }
                setSending(false);
            }, (error)=>{
                (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)("Invalid", {
                    position: "bottom-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light"
                });
                setSending(false);
            });
        } else {
            (0,react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast)("Wrong OTP", {
                position: "bottom-center",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light"
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Modal, {
        show: show,
        // onHide={handleClose}
        // onHide={() => { }}
        size: "lg",
        "aria-labelledby": "contained-modal-title-vcenter",
        centered: true,
        className: "mobilepopud coupon-modal login-modal",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Modal.Body, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "section-login-background",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "section-model-login",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "headsecftion",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    className: "imagelogo",
                                    src: "https://admin.glamcode.in/img/fav.png",
                                    alt: "Glamcode"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bottomsecftion",
                                children: mainOtp ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: handleSubmit(onOtp),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "inputField",
                                            placeholder: "Otp",
                                            defaultValue: "",
                                            maxLength: 4,
                                            ...register("otp", {
                                                required: "Otp is Required"
                                            }),
                                            onKeyUp: ()=>{
                                                trigger("otp");
                                            }
                                        }),
                                        errors.otp && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            style: {
                                                marginLeft: "58px",
                                                color: "red"
                                            },
                                            children: errors.otp.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            disabled: sending,
                                            className: "button",
                                            children: "Verify"
                                        })
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: handleSubmit(onSubmit),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "inputField",
                                            maxLength: 10,
                                            placeholder: "Enter the 10 digit mobile",
                                            defaultValue: "",
                                            ...register("phone", {
                                                required: "Phone is Required",
                                                pattern: {
                                                    value: /^\s*(?:\+?(\d{1,3}))?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{4})(?: *x(\d+))?\s*$/,
                                                    message: "Invalid Phone No"
                                                }
                                            }),
                                            onKeyUp: ()=>{
                                                trigger("phone");
                                            }
                                        }),
                                        errors.phone && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            style: {
                                                marginLeft: "58px",
                                                color: "red"
                                            },
                                            children: errors.phone.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            disabled: sending,
                                            className: "button",
                                            children: "Send OTP"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, {})
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ct": () => (/* binding */ LOCATION),
/* harmony export */   "D1": () => (/* binding */ MAIN_CATEGORY),
/* harmony export */   "G2": () => (/* binding */ ADD_TO_CART),
/* harmony export */   "OZ": () => (/* binding */ REMOVE_FROM_CART),
/* harmony export */   "XH": () => (/* binding */ HOME_DATA),
/* harmony export */   "bl": () => (/* binding */ USERADDRESS),
/* harmony export */   "hM": () => (/* binding */ USERDATA),
/* harmony export */   "qX": () => (/* binding */ CLEAR_CART),
/* harmony export */   "rZ": () => (/* binding */ DECREMENT_QTY)
/* harmony export */ });
/* unused harmony export INCREMENT_QTY */
const HOME_DATA = "HOME_DATA";
//MAIN_CATEGORY page
const MAIN_CATEGORY = "MAIN_CATEGORY";
//location
const LOCATION = "LOCATION";
//user data
const USERDATA = "USERDATA";
const USERADDRESS = "USERADDRESS";
//CART
const ADD_TO_CART = "ADD_TO_CART";
const REMOVE_FROM_CART = "REMOVE_FROM_CART";
const CLEAR_CART = "CLEAR_CART";
const INCREMENT_QTY = "INCREMENT_QTY";
const DECREMENT_QTY = "DECREMENT_QTY";


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ })

};
;