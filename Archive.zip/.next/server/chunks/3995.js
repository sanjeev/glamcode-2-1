"use strict";
exports.id = 3995;
exports.ids = [3995];
exports.modules = {

/***/ 1490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/facebook2.a93501b0.svg","height":1080,"width":1080});

/***/ }),

/***/ 7194:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/instargram.870552ca.svg","height":1080,"width":1080});

/***/ }),

/***/ 8029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/pin.d48d2991.svg","height":1080,"width":1080});

/***/ }),

/***/ 7935:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/reddit.165b1299.svg","height":1080,"width":1080});

/***/ }),

/***/ 8804:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/twitter.df60f581.svg","height":1080,"width":1080});

/***/ }),

/***/ 216:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/youtube.9da92f18.svg","height":1080,"width":1080});

/***/ }),

/***/ 3:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_img_facebook2_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1490);
/* harmony import */ var _assets_img_instargram_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7194);
/* harmony import */ var _assets_img_pin_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8029);
/* harmony import */ var _assets_img_reddit_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7935);
/* harmony import */ var _assets_img_twitter_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8804);
/* harmony import */ var _assets_img_youtube_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(216);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _services_front_services__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1150);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__]);
react_toastify__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// import 'react-toastify/dist/ReactToastify.css';











function Footer() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.cardAdd?.cart);
    const [total, setTotal] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(0);
    const [coupons, setCoupons] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const dataloctions = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.loctions);
    const renderInput = ()=>{
        router.push("/login");
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        var total = 0;
        for(let i = 0; i < cart.length; i++){
            total += parseInt(cart[i].sum);
        }
        setTotal(total);
    }, [
        cart
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // setError("")
        var day = moment__WEBPACK_IMPORTED_MODULE_11___default()().format("dddd");
        _services_front_services__WEBPACK_IMPORTED_MODULE_12__/* .frontService.coupons */ .Z.coupons().then((res)=>{
            if (res.status === "success") {
                setCoupons((arr)=>[
                        ...res.couponData.filter((e)=>isDay(e.days, day))
                    ]);
            } else {
            // setError('Something went wrong !!');
            }
        // setLoading(false)
        }, (error)=>{
        // setLoading(false)
        // setError('Something went wrong !!');
        });
    }, []);
    const selecthandleclick = (locId, locName, locAddress, locationslug, locMinBookingAmount)=>{
        localStorage.setItem("id", locId);
        localStorage.setItem("cityname", locName);
        localStorage.setItem("locAddress", locAddress);
        localStorage.setItem("loc_min_booking_amount", locMinBookingAmount);
        router.push("/" + locationslug);
        window.location.href = "/" + locationslug;
    //Router.reload(window.location.pathname)
    };
    const shortedCoupons = coupons.sort((a, b)=>a.minimum_purchase_amount - b.minimum_purchase_amount);
    let dif = ((shortedCoupons[0] || {}).minimum_purchase_amount || 0) - total;
    let minAmount = localStorage.getItem("loc_min_booking_amount") || "0";
    minAmount = parseInt(minAmount);
    if (minAmount > total) {
        dif = 0;
    }
    const isDay = (s, day)=>{
        let string = s.replaceAll('"', "");
        string = string.replace("[", "");
        string = string.replace("]", "");
        string = string.replaceAll('"', "");
        string = string.split(",");
        let has = false;
        string.forEach((element)=>{
            if (!has) {
                if (element === day) {
                    has = true;
                }
            }
        });
        return has;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
                className: "footer-container",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-12 col-lg-2 tc",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "/about-us",
                                            className: "footer-text",
                                            children: "About Us"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-12 col-lg-2 tc",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "/terms-conditions",
                                            className: "footer-text",
                                            children: "Terms & conditions"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-12 col-lg-2 tc",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "/privacy-policy",
                                            className: "footer-text",
                                            children: "Privacy Policy"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-12 col-lg-2 tc",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "/",
                                            className: "footer-text",
                                            children: "Faqs"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-12 col-lg-2 tc",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "/",
                                            className: "footer-text",
                                            children: "Contact Us"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                style: {
                                    border: "1px solid rgb(255, 255, 255)"
                                }
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-7 col-lg-7",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "footer-text",
                                        children: localStorage.getItem("locAddress") ? localStorage.getItem("locAddress") : "Amrapali Zodiac, Sector 120, Noida, Uttar Pradesh, India"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-5 col-lg-5 bv",
                                    style: {
                                        color: "#fff"
                                    },
                                    children: dataloctions.location?.map((x, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            onClick: ()=>selecthandleclick(x.id, x.city, x.name, x.slug, x.price),
                                            style: {
                                                color: "#fff"
                                            },
                                            href: `/${x.slug}`,
                                            children: [
                                                " ",
                                                x.city,
                                                ", "
                                            ]
                                        }, i))
                                })
                            ]
                        })
                    ]
                })
            }),
            localStorage.getItem("devise") === "D" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        position: "fixed",
                        zIndex: 9,
                        right: 0,
                        top: "30%"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: " me-auto mb-2 mb-lg-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "https://twitter.com/GlamCode3?t=medt6YYBVczVXZ-IWiUObg&s=08",
                                    className: "social-icon",
                                    style: {
                                        display: "inline-block",
                                        width: 50,
                                        height: 50,
                                        position: "relative",
                                        overflow: "hidden",
                                        verticalAlign: "middle"
                                    },
                                    target: "_blank",
                                    "aria-label": "twitter",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "social-container",
                                        style: {
                                            position: "absolute",
                                            top: 0,
                                            left: 0,
                                            width: "100%",
                                            height: "100%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: _assets_img_twitter_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"].src */ .Z.src
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "https://www.facebook.com/myglamcode",
                                    className: "social-icon",
                                    target: "_blank",
                                    style: {
                                        display: "inline-block",
                                        width: 50,
                                        height: 50,
                                        position: "relative",
                                        overflow: "hidden",
                                        verticalAlign: "middle"
                                    },
                                    "aria-label": "facebook",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "social-container",
                                        style: {
                                            position: "absolute",
                                            top: 0,
                                            left: 0,
                                            width: "100%",
                                            height: "100%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: _assets_img_facebook2_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"].src */ .Z.src
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "https://instagram.com/myglamcode?igshid=YmMyMTA2M2Y=",
                                    className: "social-icon",
                                    style: {
                                        display: "inline-block",
                                        width: 50,
                                        height: 50,
                                        position: "relative",
                                        overflow: "hidden",
                                        verticalAlign: "middle"
                                    },
                                    target: "_blank",
                                    "aria-label": "instagram",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "social-container",
                                        style: {
                                            position: "absolute",
                                            top: 0,
                                            left: 0,
                                            width: "100%",
                                            height: "100%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: _assets_img_instargram_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"].src */ .Z.src
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "https://youtube.com/channel/UC0tPgNGS96oVlkUqBf4ZM2Q",
                                    className: "social-icon",
                                    style: {
                                        display: "inline-block",
                                        width: 50,
                                        height: 50,
                                        position: "relative",
                                        overflow: "hidden",
                                        verticalAlign: "middle"
                                    },
                                    target: "_blank",
                                    "aria-label": "youtube",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "social-container",
                                        style: {
                                            position: "absolute",
                                            top: 0,
                                            left: 0,
                                            width: "100%",
                                            height: "100%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: _assets_img_youtube_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"].src */ .Z.src
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "https://www.reddit.com/u/myglamcode/?utm_source=share&utm_medium=ios_app&utm_name=iossmf",
                                    className: "social-icon",
                                    target: "_blank",
                                    style: {
                                        display: "inline-block",
                                        width: 50,
                                        height: 50,
                                        position: "relative",
                                        overflow: "hidden",
                                        verticalAlign: "middle"
                                    },
                                    "aria-label": "reddit",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "social-container",
                                        style: {
                                            position: "absolute",
                                            top: 0,
                                            left: 0,
                                            width: "100%",
                                            height: "100%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: _assets_img_reddit_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"].src */ .Z.src
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "https://pin.it/1DMbsqq",
                                    className: "social-icon",
                                    target: "_blank",
                                    style: {
                                        display: "inline-block",
                                        width: 50,
                                        height: 50,
                                        position: "relative",
                                        overflow: "hidden",
                                        verticalAlign: "middle"
                                    },
                                    "aria-label": "sharethis",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "social-container",
                                        style: {
                                            position: "absolute",
                                            top: 0,
                                            left: 0,
                                            width: "100%",
                                            height: "100%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: _assets_img_pin_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"].src */ .Z.src
                                        })
                                    })
                                })
                            })
                        ]
                    })
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: " me-auto mb-2 mb-lg-0",
                    style: {
                        display: "flex",
                        justifyContent: "center",
                        paddingLeft: "0px",
                        marginTop: "10px"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://twitter.com/GlamCode3?t=medt6YYBVczVXZ-IWiUObg&s=08",
                                className: "social-icon",
                                style: {
                                    display: "inline-block",
                                    width: 50,
                                    height: 50,
                                    position: "relative",
                                    overflow: "hidden",
                                    verticalAlign: "middle"
                                },
                                target: "_blank",
                                "aria-label": "twitter",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "social-container",
                                    style: {
                                        position: "absolute",
                                        top: 0,
                                        left: 0,
                                        width: "100%",
                                        height: "100%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: _assets_img_twitter_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"].src */ .Z.src
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://www.facebook.com/myglamcode",
                                className: "social-icon",
                                target: "_blank",
                                style: {
                                    display: "inline-block",
                                    width: 50,
                                    height: 50,
                                    position: "relative",
                                    overflow: "hidden",
                                    verticalAlign: "middle"
                                },
                                "aria-label": "facebook",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "social-container",
                                    style: {
                                        position: "absolute",
                                        top: 0,
                                        left: 0,
                                        width: "100%",
                                        height: "100%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: _assets_img_facebook2_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"].src */ .Z.src
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://instagram.com/myglamcode?igshid=YmMyMTA2M2Y=",
                                className: "social-icon",
                                style: {
                                    display: "inline-block",
                                    width: 50,
                                    height: 50,
                                    position: "relative",
                                    overflow: "hidden",
                                    verticalAlign: "middle"
                                },
                                target: "_blank",
                                "aria-label": "instagram",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "social-container",
                                    style: {
                                        position: "absolute",
                                        top: 0,
                                        left: 0,
                                        width: "100%",
                                        height: "100%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: _assets_img_instargram_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"].src */ .Z.src
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://youtube.com/channel/UC0tPgNGS96oVlkUqBf4ZM2Q",
                                className: "social-icon",
                                style: {
                                    display: "inline-block",
                                    width: 50,
                                    height: 50,
                                    position: "relative",
                                    overflow: "hidden",
                                    verticalAlign: "middle"
                                },
                                target: "_blank",
                                "aria-label": "youtube",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "social-container",
                                    style: {
                                        position: "absolute",
                                        top: 0,
                                        left: 0,
                                        width: "100%",
                                        height: "100%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: _assets_img_youtube_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"].src */ .Z.src
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://www.reddit.com/u/myglamcode/?utm_source=share&utm_medium=ios_app&utm_name=iossmf",
                                className: "social-icon",
                                target: "_blank",
                                style: {
                                    display: "inline-block",
                                    width: 50,
                                    height: 50,
                                    position: "relative",
                                    overflow: "hidden",
                                    verticalAlign: "middle"
                                },
                                "aria-label": "reddit",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "social-container",
                                    style: {
                                        position: "absolute",
                                        top: 0,
                                        left: 0,
                                        width: "100%",
                                        height: "100%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: _assets_img_reddit_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"].src */ .Z.src
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://pin.it/1DMbsqq",
                                className: "social-icon",
                                target: "_blank",
                                style: {
                                    display: "inline-block",
                                    width: 50,
                                    height: 50,
                                    position: "relative",
                                    overflow: "hidden",
                                    verticalAlign: "middle"
                                },
                                "aria-label": "sharethis",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "social-container",
                                    style: {
                                        position: "absolute",
                                        top: 0,
                                        left: 0,
                                        width: "100%",
                                        height: "100%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: _assets_img_pin_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"].src */ .Z.src
                                    })
                                })
                            })
                        })
                    ]
                })
            }),
            router.pathname === "/login" || router.pathname === "/payment" || router.pathname === "/checkout" ? "" : cart.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "bottomservicesCheckout",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "topinside",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text",
                            children: `Minimum Booking Amount :- ₹  ${localStorage.getItem("loc_min_booking_amount")}`
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "bottominside",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "d-flex justify-content-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "d-flex flex-column-m",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "textHead",
                                        children: [
                                            "Total Price ₹ ",
                                            total,
                                            " ",
                                            " ",
                                            dif > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                style: {
                                                    paddingLeft: "6px"
                                                },
                                                children: ` Add ₹${dif} more to avail coupon`
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    onClick: ()=>{
                                        let minAmount = localStorage.getItem("loc_min_booking_amount") || "0";
                                        minAmount = parseInt(minAmount);
                                        localStorage.setItem("page", "checkout");
                                        if (minAmount > total) {
                                            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error("Add more items to checkout");
                                        } else if (!localStorage.getItem("gluserDetails")) {
                                            router.push("/login");
                                        } else {
                                            router.push("/checkout");
                                        }
                                    },
                                    className: "textHead",
                                    style: {
                                        cursor: "pointer"
                                    },
                                    children: [
                                        "Checkout ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fa fa-chevron-right",
                                            style: {
                                                marginLeft: 10
                                            },
                                            "aria-hidden": "true"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }, 0) : ""
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2665);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3);
/* harmony import */ var _LoadingScreen_loadingScreen__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8004);
/* harmony import */ var _services_front_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1150);
/* harmony import */ var _store_actions_index__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6051);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _responsiveCheck__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4430);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Footer__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_7__]);
([_Footer__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function Layout({ children  }) {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const val = (0,_responsiveCheck__WEBPACK_IMPORTED_MODULE_8__/* .responsiveReturn */ .l)("D", "M", 991);
    const [loading, setLoading] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(true);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        localStorage.setItem("devise", val);
        setTimeout(()=>{
            setLoading(false);
        }, 200);
    }, []);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        _services_front_services__WEBPACK_IMPORTED_MODULE_5__/* .frontService.allSlider */ .Z.allSlider().then((res)=>{
            if (res.status === "success") {
                dispatch((0,_store_actions_index__WEBPACK_IMPORTED_MODULE_9__/* .menuSave */ .kP)(res.slider_images));
            } else {
                console.log("Something went wrong !!");
            }
        }, (error)=>{
            console.log("Something went wrong !!");
        });
        _services_front_services__WEBPACK_IMPORTED_MODULE_5__/* .frontService.maincategory */ .Z.maincategory().then((res)=>{
            if (res.status === "success") {
                dispatch((0,_store_actions_index__WEBPACK_IMPORTED_MODULE_9__/* .mainCategory */ .FI)(res.maincategory));
            } else {
                console.log("Something went wrong !!");
            }
        }, (error)=>{
            console.log("Something went wrong !!");
        //toast.error("Something went wrong !!", "Fashion Store");
        });
        _services_front_services__WEBPACK_IMPORTED_MODULE_5__/* .frontService.locationall */ .Z.locationall().then((res)=>{
            if (res.status === "success") {
                dispatch((0,_store_actions_index__WEBPACK_IMPORTED_MODULE_9__/* .mainLocation */ .dG)(res.locations));
            } else {
                console.log("Something went wrong !!");
            }
        }, (error)=>{
            console.log("Something went wrong !!");
        //toast.error("Something went wrong !!", "Fashion Store");
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_7__.ToastContainer, {}),
            !loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "allsection",
                        children: children
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LoadingScreen_loadingScreen__WEBPACK_IMPORTED_MODULE_4__["default"], {})
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ responsiveReturn)
/* harmony export */ });
const responsiveReturn = (desktop, mobile, widthCheck)=>{
    if (false) {}
};


/***/ })

};
;