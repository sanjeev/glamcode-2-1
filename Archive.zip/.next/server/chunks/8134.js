"use strict";
exports.id = 8134;
exports.ids = [8134];
exports.modules = {

/***/ 8134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ AddToCart)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6051);



function AddToCart({ data  }) {
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.cardAdd?.cart);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const inCart = cart.filter((e)=>e.id === data.id);
    const onDecrement = (itemsid)=>{
        if (Math.max(inCart[0].qty - 1, 0) === 0) {
            dispatch((0,_store_actions__WEBPACK_IMPORTED_MODULE_2__/* .removeFromCart */ .h2)(itemsid));
        } else {
            dispatch((0,_store_actions__WEBPACK_IMPORTED_MODULE_2__/* .decrementQty */ .fh)(itemsid, 1));
        }
    };
    const onIncrement = (items)=>{
        dispatch((0,_store_actions__WEBPACK_IMPORTED_MODULE_2__/* .addtoCartData */ .aL)(items, 1));
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "pb-2",
            children: inCart.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-0 Addtocart-Items-m Addtocart d-inline-flex gap-xl-3 gap-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "addcart-minus",
                        onClick: ()=>onDecrement(data.id),
                        children: "-"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "addcart-count",
                        children: inCart[0].qty
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "addcart-plus",
                        onClick: ()=>onIncrement(data),
                        children: "+"
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "Addtocart d-inline-flex gap-3",
                onClick: ()=>onIncrement(data),
                children: "Add"
            })
        })
    });
}


/***/ })

};
;