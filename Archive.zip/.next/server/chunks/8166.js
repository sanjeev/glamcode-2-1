"use strict";
exports.id = 8166;
exports.ids = [8166];
exports.modules = {

/***/ 8166:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ViewDetails)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-bootstrap/Modal"
var Modal_ = __webpack_require__(9306);
var Modal_default = /*#__PURE__*/__webpack_require__.n(Modal_);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: ./store/actions/index.js
var actions = __webpack_require__(6051);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./components/Cart/AddToCartModalView.js



function AddToCartModalView({ data  }) {
    const cart = (0,external_react_redux_.useSelector)((state)=>state.cardAdd?.cart);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const inCart = cart.filter((e)=>e.id === data.id);
    const onDecrement = (itemsid)=>{
        if (Math.max(inCart[0].qty - 1, 0) === 0) {
            dispatch((0,actions/* removeFromCart */.h2)(itemsid));
        } else {
            dispatch((0,actions/* decrementQty */.fh)(itemsid, 1));
        }
    };
    const onIncrement = (items)=>{
        dispatch((0,actions/* addtoCartData */.aL)(items, 1));
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: inCart.length > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mt-0 Addtocart-Items-m Addtocart d-inline-flex gap-xl-3 gap-1 position-relative w-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "addcart-minus",
                    onClick: ()=>onDecrement(data.id),
                    children: "-"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "addcart-count",
                    children: inCart[0].qty
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "addcart-plus",
                    onClick: ()=>onIncrement(data),
                    children: "+"
                })
            ]
        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
            id: "cart-btn",
            className: "position-relative d-inline-flex",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "Addtocart position-relative d-inline-flex gap-3",
                onClick: ()=>onIncrement(data),
                children: "Add"
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/Modal/ViewCenteredModal.js







function ViewCenteredModal(props) {
    const handleClose = ()=>props.onHide();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const [itemCount, setItemCount] = external_react_default().useState(0);
    const onDecrement = (itemsid)=>{
        setItemCount(Math.max(itemCount - 1, 0));
        if (Math.max(itemCount - 1, 0) === 0) {
            dispatch((0,actions/* removeFromCart */.h2)(itemsid));
        } else {
            dispatch((0,actions/* decrementQty */.fh)(itemsid, 1));
        }
    };
    const onIncrement = (items)=>{
        setItemCount(itemCount + 1);
        //     dispatch({
        //         type: 'FETCH_DATA',
        //         data: responseData
        //    })
        dispatch((0,actions/* addtoCartData */.aL)(items, 1));
    };
    const mapItems = (items)=>{
        return items.map((item, index)=>{
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa fa-snowflake-o",
                        "aria-hidden": "true"
                    }),
                    ` ` + item.toString()
                ]
            }, index);
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Modal_default()), {
            ...props,
            fullscreen: true,
            "aria-labelledby": "contained-modal-title-vcenter",
            centered: true,
            className: "mobilepopud",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    onClick: handleClose,
                    className: "image-d-location-close",
                    children: "X"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Modal_default()).Body, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                md: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "product-single-thumb",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: props.datato.service_image_url,
                                        alt: "Luxury Party Makeup",
                                        className: "popimag"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                md: 6,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "product-details-content",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                            className: "product-details-title",
                                            children: [
                                                " ",
                                                props.datato.name
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "product-details-review mb-1",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "product-review-icon",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-star"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-star-half-o"
                                                    })
                                                ]
                                            })
                                        }),
                                        props.datato.description && /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            className: "mb-6",
                                            style: {
                                                paddingLeft: "0px"
                                            },
                                            children: mapItems(props.datato.description.replace(/(<([^>]+)>)/ig, "").replace(/(?:\r\n|\r|\n)/g, "").replace(/(?:&nbsp;)/g, "").replace(/&amp;/g, "&").toString().split("."))
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "mb-6",
                                            children: " "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "product-details-pro-qty",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(AddToCartModalView, {
                                                data: props.datato
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "product-details-action",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "product-item prices",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "price",
                                                            children: [
                                                                "₹ ",
                                                                Math.round(props.datato.discounted_price)
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "price-old",
                                                            style: {
                                                                textDecorationLine: "line-through"
                                                            },
                                                            children: [
                                                                "₹ ",
                                                                Math.round(props.datato.price)
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "product-details-cart-wishlist",
                                                    style: {
                                                        marginLeft: "35px"
                                                    },
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                        type: "button",
                                                        className: "btn",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fa fa-clock-o"
                                                            }),
                                                            "\xa0",
                                                            props.datato.time,
                                                            " ",
                                                            props.datato.time_type
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/ViewDetails/ViewDetails.js



function ViewDetails(props) {
    const [modalShow, setModalShow] = external_react_default().useState(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `viewDetails ${props.devise}`,
                onClick: ()=>setModalShow(true),
                children: "View Details"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ViewCenteredModal, {
                show: modalShow,
                onHide: ()=>setModalShow(false),
                datato: props.alldata
            })
        ]
    });
}


/***/ })

};
;