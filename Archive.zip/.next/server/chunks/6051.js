"use strict";
exports.id = 6051;
exports.ids = [6051];
exports.modules = {

/***/ 6051:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FI": () => (/* binding */ mainCategory),
/* harmony export */   "LL": () => (/* binding */ clearCart),
/* harmony export */   "ZW": () => (/* binding */ userData),
/* harmony export */   "aL": () => (/* binding */ addtoCartData),
/* harmony export */   "dG": () => (/* binding */ mainLocation),
/* harmony export */   "fh": () => (/* binding */ decrementQty),
/* harmony export */   "h2": () => (/* binding */ removeFromCart),
/* harmony export */   "kP": () => (/* binding */ menuSave),
/* harmony export */   "tP": () => (/* binding */ userAddress)
/* harmony export */ });
/* unused harmony exports addToCart, AddToCartAndRemoveWishlist, incrementQty */
/* harmony import */ var _actionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5044);

function menuSave(payload) {
    return {
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .HOME_DATA */ .XH,
        payload: payload
    };
}
function userData(payload) {
    return {
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .USERDATA */ .hM,
        payload: payload
    };
}
function userAddress(payload) {
    return {
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .USERADDRESS */ .bl,
        payload: payload
    };
}
function mainCategory(payload) {
    return {
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .MAIN_CATEGORY */ .D1,
        payload: payload
    };
}
function mainLocation(payload) {
    return {
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .LOCATION */ .Ct,
        payload: payload
    };
}
function addToCart(product, qty) {
    // console.log("Item Added to Cart !!");
    dispatch(addtoCartData(product, qty));
}
// export const addToCart = (product, qty) => (dispatch) => {
//     console.log("Item Added to Cart !!");
//     console.log(product);
//     //dispatch(addtoCartData(product, qty));
// };
const decrementQty = (productId)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .DECREMENT_QTY */ .rZ,
        productId
    });
const addtoCartData = (product, qty)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .ADD_TO_CART */ .G2,
        product,
        qty
    });
const removeFromCart = (productId)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .REMOVE_FROM_CART */ .OZ,
        product_Id: productId
    });
const clearCart = ()=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .CLEAR_CART */ .qX,
        product_Id: ""
    });
// export const removeFromCart = productId => (dispatch) => {
//     dispatch({
//         type: types.REMOVE_FROM_CART,
//         product_Id: productId
//     });
// }
const AddToCartAndRemoveWishlist = (product, qty)=>(dispatch1)=>{
        toast.success("Item Added to Cart !!");
        dispatch1(addToCart(product, qty));
        dispatch1(removeFromWishlist(product.id));
    };
// export const removeFromCart = productId => (dispatch) => {
//     toast.success("Item Removed from Cart !!");
//     dispatch({
//         type: types.REMOVE_FROM_CART,
//         product_Id: productId
//     });
// }
// export const decrementQty = (productId) => ({
//     type: types.DECREMENT_QTY,
//     productId
// });
// export const decrementQty = (productId) => ({
//     type: types.DECREMENT_QTY,
//     productId
// });
// export function decrementQty(productId) {
//     return {
//         type: types.DECREMENT_QTY,
//         productId
//     }
// }
// export const decrementQty = (productId) => (dispatch) => {
//     toast.success("Item Decrement Qty to Cart !!");
//     dispatch({
//         type: types.DECREMENT_QTY,
//         productId
//     });
// }
const incrementQty = (product, qty)=>(dispatch1)=>{
        toast.success("Item Added to Cart !!");
        dispatch1(addtoCartData(product, qty));
    };


/***/ })

};
;