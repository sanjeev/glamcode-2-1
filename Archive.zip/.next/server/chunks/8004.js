"use strict";
exports.id = 8004;
exports.ids = [8004];
exports.modules = {

/***/ 8004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ loadingScreen)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/img/glamcodepreloader.gif
/* harmony default export */ const glamcodepreloader = ({"src":"/_next/static/media/glamcodepreloader.0dd2e47e.gif","height":450,"width":800});
;// CONCATENATED MODULE: ./components/LoadingScreen/loadingScreen.js





const Screen = (external_styled_components_default()).div`
  position: relative;
  height: 100vh;
  width: 100%;
  opacity: 0;
  animation: fade 0.4s ease-in forwards;


  @keyframes fade {
    0% {
      opacity: 0.4;
    }
    50% {
      opacity: 0.8;
    }
    100% {
      opacity: 1;
    }
  }
`;
const Balls = (external_styled_components_default()).div`
  display: flex;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);

  .ball {
    height: 20px;
    width: 20px;
    border-radius: 50%;
    background: #1b5299;
    margin: 0 6px 0 0;
    animation: oscillate 0.7s ease-in forwards infinite;
  }

  .one {
    animation-delay: 0.5s;
  }
  .two {
    animation-delay: 1s;
  }
  .three {
    animation-delay: 2s;
  }

  @keyframes oscillate {
    0% {
      transform: translateY(0);
    }
    50% {
      transform: translateY(20px);
    }
    100% {
      transform: translateY(0);
    }
  }
`;
const LoadingScreen = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Screen, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Balls, {
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: "logoloaderimg",
                width: 500,
                height: 500,
                src: glamcodepreloader.src,
                alt: "Glamcode"
            })
        })
    });
};
/* harmony default export */ const loadingScreen = (LoadingScreen);


/***/ })

};
;