"use strict";
exports.id = 5044;
exports.ids = [5044,6746,699];
exports.modules = {

/***/ 5044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ct": () => (/* binding */ LOCATION),
/* harmony export */   "D1": () => (/* binding */ MAIN_CATEGORY),
/* harmony export */   "G2": () => (/* binding */ ADD_TO_CART),
/* harmony export */   "OZ": () => (/* binding */ REMOVE_FROM_CART),
/* harmony export */   "XH": () => (/* binding */ HOME_DATA),
/* harmony export */   "bl": () => (/* binding */ USERADDRESS),
/* harmony export */   "hM": () => (/* binding */ USERDATA),
/* harmony export */   "qX": () => (/* binding */ CLEAR_CART),
/* harmony export */   "rZ": () => (/* binding */ DECREMENT_QTY)
/* harmony export */ });
/* unused harmony export INCREMENT_QTY */
const HOME_DATA = "HOME_DATA";
//MAIN_CATEGORY page
const MAIN_CATEGORY = "MAIN_CATEGORY";
//location
const LOCATION = "LOCATION";
//user data
const USERDATA = "USERDATA";
const USERADDRESS = "USERADDRESS";
//CART
const ADD_TO_CART = "ADD_TO_CART";
const REMOVE_FROM_CART = "REMOVE_FROM_CART";
const CLEAR_CART = "CLEAR_CART";
const INCREMENT_QTY = "INCREMENT_QTY";
const DECREMENT_QTY = "DECREMENT_QTY";


/***/ })

};
;