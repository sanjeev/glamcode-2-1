"use strict";
exports.id = 1150;
exports.ids = [1150];
exports.modules = {

/***/ 7909:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Global)
/* harmony export */ });
/* unused harmony export range */
class Global {
    // static BASE_API_PATH = "http://localhost:8080/api";
    static BASE_API_PATH = "https://admin.glamcode.in/api";
    static BASE_IMG_PATH = "https://admin.glamcode.in/user-uploads/locations/";
    static BASE_APP_PATH = "https://admin.glamcode.in";
}
;
const range = (from, to, step)=>[
        ...Array(Math.floor((to - from) / step) + 1)
    ].map((_, i)=>from + i * step);


/***/ }),

/***/ 1150:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ frontService)
/* harmony export */ });
/* harmony import */ var _helpers_global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7909);

const frontService = {
    search,
    allSlider,
    maincategory,
    allfaqs,
    locationall,
    knowData,
    knowDataSlug,
    datamancat,
    sendOtpcode,
    sendOtpverify,
    useSave,
    updateAddress,
    addressList,
    deleteaddress,
    defaultaddress,
    blogs,
    blogDetails,
    coupons,
    bookOrder,
    myBookings,
    cancelBooking,
    preferredPack,
    contact,
    loctionSlug
};
async function search(s, location) {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/search?search_term=${s}&location=${location}`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function blogs() {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/list-blogs`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function coupons() {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/coupons-list`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function blogDetails(id) {
    const data = {
        id: id
    };
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/blogs-details`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function allSlider() {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/allslider`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function useSave(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/update-user`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function addressList(id) {
    const data = {
        user_id: id
    };
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/address-list`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function deleteaddress(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/address-delete`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function defaultaddress(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/address-default`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function updateAddress(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/update-user-address`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function sendOtpcode(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/sendotpcode`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function bookOrder(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/booking-save`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function sendOtpverify(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/verifyotpphone`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function datamancat() {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/category/${localStorage.getItem("mid")}/${localStorage.getItem("id") || localStorage.getItem("tid")}`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function maincategory() {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/maincategory/${localStorage.getItem("id") ? localStorage.getItem("id") : "2"}`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function locationall() {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/alllocation`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function knowData() {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/knowdata/${localStorage.getItem("id") ? localStorage.getItem("id") : "2"}`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function knowDataSlug(slug) {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/knowdataslug/${slug}`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function loctionSlug(slug) {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/loctionSlug/${slug}`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function allfaqs() {
    const requestOptions = {
        method: "GET"
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/faqs/${localStorage.getItem("id") ? localStorage.getItem("id") : "2"}`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
function handleResponse(response) {
    if (response.ok === false) {
        if (response.statusText === "Unauthorized") {
            localStorage.removeItem("userDetails");
            localStorage.removeItem("userdata");
            localStorage.removeItem("gluserDetails");
            localStorage.removeItem("page");
            window.location = "/";
        }
    } else {
        return response.text().then((text)=>{
            const data = JSON.parse(text);
            if (!response.ok) {
                if (response.status === 401) {
                // console.log(response);
                }
                const error = data && data.message || response.statusText;
                return Promise.reject(error);
            }
            return data;
        });
    }
}
async function myBookings(id) {
    const data = {
        user_id: id
    };
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/bookingsdata`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function cancelBooking(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/cancel-reschedule`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function preferredPack(id) {
    const data = {
        location_id: id
    };
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/preferredpack`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}
async function contact(data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return fetch(_helpers_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"].BASE_API_PATH */ .Z.BASE_API_PATH + `/contact`, requestOptions).then(handleResponse).then((res)=>{
        return res;
    });
}


/***/ })

};
;