(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888,7273];
exports.modules = {

/***/ 7273:
/***/ ((__unused_webpack_module, exports) => {

"use strict";
var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
Object.defineProperty(exports, "Z", ({
    enumerable: true,
    get: function() {
        return _objectWithoutPropertiesLoose;
    }
}));
function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}


/***/ }),

/***/ 876:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./styles/mobilepage.css
var mobilepage = __webpack_require__(3318);
// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.css
var bootstrap = __webpack_require__(5931);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
// EXTERNAL MODULE: ./store/actionTypes.js
var actionTypes = __webpack_require__(5044);
;// CONCATENATED MODULE: ./store/reducers/HomeReducers.js

const initialState = {
    isConfirmatiom: false,
    media: []
};
function addressSaveReducer(state = initialState, action) {
    switch(action.type){
        case actionTypes/* HOME_DATA */.XH:
            return {
                ...state,
                isConfirmatiom: true,
                media: action.payload
            };
        default:
            return state;
    }
}
/* harmony default export */ const HomeReducers = (addressSaveReducer);

;// CONCATENATED MODULE: ./store/reducers/mainCatReducers.js

const mainCatReducers_initialState = {
    isConfirmatiom: false,
    maincategory: []
};
function mainCatReducers(state = mainCatReducers_initialState, action) {
    switch(action.type){
        case actionTypes/* MAIN_CATEGORY */.D1:
            return {
                ...state,
                isConfirmatiom: true,
                maincategory: action?.payload
            };
        default:
            return state;
    }
}
/* harmony default export */ const reducers_mainCatReducers = (mainCatReducers);

;// CONCATENATED MODULE: ./store/reducers/locationReducers.js

const locationReducers_initialState = {
    isConfirmatiom: false,
    location: []
};
function locationReducers_addressSaveReducer(state = locationReducers_initialState, action) {
    switch(action.type){
        case actionTypes/* LOCATION */.Ct:
            return {
                ...state,
                isConfirmatiom: true,
                location: action.payload
            };
        default:
            return state;
    }
}
/* harmony default export */ const locationReducers = (locationReducers_addressSaveReducer);

;// CONCATENATED MODULE: ./store/reducers/UserReducers.js

const UserReducers_initialState = {
    isConfirmatiom: false,
    userdetails: []
};
function userReducer(state = UserReducers_initialState, action) {
    switch(action.type){
        case actionTypes/* USERDATA */.hM:
            return {
                ...state,
                isConfirmatiom: true,
                userdetails: action.payload
            };
        default:
            return state;
    }
}
/* harmony default export */ const UserReducers = (userReducer);

;// CONCATENATED MODULE: ./store/reducers/cart.js

function cartReducer(state = {
    cart: []
}, action) {
    switch(action.type){
        case actionTypes/* ADD_TO_CART */.G2:
            // debugger;
            const productId = action.product.id;
            if (state.cart.findIndex((product)=>product.id === productId) !== -1) {
                const cart = state.cart.reduce((cartAcc, product)=>{
                    if (product.id === productId) {
                        cartAcc.push({
                            ...product,
                            qty: product.qty + 1,
                            sum: product.discounted_price * (product.qty + 1)
                        });
                    } else {
                        cartAcc.push(product);
                    }
                    return cartAcc;
                }, []);
                return {
                    ...state,
                    cart
                };
            }
            return {
                ...state,
                cart: [
                    ...state.cart,
                    {
                        ...action.product,
                        qty: action.qty,
                        sum: action.product.discounted_price * action.qty
                    }
                ]
            };
        case actionTypes/* DECREMENT_QTY */.rZ:
            if (state.cart.findIndex((product)=>product.id === action.productId) !== -1) {
                const cart1 = state.cart.reduce((cartAcc, product)=>{
                    if (product.id === action.productId && product.qty > 1) {
                        cartAcc.push({
                            ...product,
                            qty: product.qty - 1,
                            sum: product.discounted_price * (product.qty - 1)
                        });
                    } else {
                        cartAcc.push(product);
                    }
                    return cartAcc;
                }, []);
                return {
                    ...state,
                    cart: cart1
                };
            }
            return {
                ...state,
                cart: [
                    ...state.cart,
                    {
                        ...action.product,
                        qty: action.qty,
                        sum: action.product.discount * action.qty
                    }
                ]
            };
        case actionTypes/* REMOVE_FROM_CART */.OZ:
            // console.log(action.product_Id);
            // const newPeople = state.cart.filter(item => item.id !== action.product_Id);
            //console.log('remove');
            return {
                cart: state.cart.filter((item)=>item.id !== action.product_Id)
            };
        case actionTypes/* CLEAR_CART */.qX:
            // console.log(action.product_Id);
            // const newPeople = state.cart.filter(item => item.id !== action.product_Id);
            //console.log('remove');
            return {
                cart: []
            };
        default:
            {}
    }
    return state;
}

;// CONCATENATED MODULE: ./store/reducers/UserAddressReduces.js

const UserAddressReduces_initialState = {
    isConfirmatiom: false,
    useraddress: []
};
function UserAddressReduces(state = UserAddressReduces_initialState, action) {
    switch(action.type){
        case actionTypes/* USERADDRESS */.bl:
            return {
                ...state,
                isConfirmatiom: true,
                useraddress: action.payload
            };
        default:
            return state;
    }
}
/* harmony default export */ const reducers_UserAddressReduces = (UserAddressReduces);

;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
;// CONCATENATED MODULE: ./store/reducers/index.js









const persistConfig = {
    key: "root",
    storage: (storage_default())
};
const rootReducer = (0,external_redux_namespaceObject.combineReducers)({
    slide: HomeReducers,
    maincat: reducers_mainCatReducers,
    loctions: locationReducers,
    cardAdd: cartReducer,
    userdetails: UserReducers,
    userAddress: reducers_UserAddressReduces
});
/* harmony default export */ const reducers = ((0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, rootReducer));

;// CONCATENATED MODULE: ./store/store.js




let composeEnhancers;
if (false) {} else {
    composeEnhancers = external_redux_namespaceObject.compose;
}
//const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const store = (0,external_redux_namespaceObject.createStore)(reducers, composeEnhancers((0,external_redux_namespaceObject.applyMiddleware)((external_redux_thunk_default()))));
const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store);
/* harmony default export */ const store_store = (store); //const composeEnhancers = compose;
 // const store = createStore(rootReducer, composeEnhancers(
 //     applyMiddleware(thunk)
 // ));
 // export default store;

;// CONCATENATED MODULE: external "redux-persist/integration/react"
const react_namespaceObject = require("redux-persist/integration/react");
// EXTERNAL MODULE: ./node_modules/font-awesome/css/font-awesome.css
var font_awesome = __webpack_require__(861);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.min.css
var swiper_min = __webpack_require__(8722);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(8819);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "react-hotjar"
const external_react_hotjar_namespaceObject = require("react-hotjar");
;// CONCATENATED MODULE: ./pages/_app.js









//import Layout from '../components/Layout/index'
const Layout = dynamic_default()(()=>Promise.all(/* import() */[__webpack_require__.e(3121), __webpack_require__.e(5675), __webpack_require__.e(9332), __webpack_require__.e(1150), __webpack_require__.e(6051), __webpack_require__.e(8004), __webpack_require__.e(2665), __webpack_require__.e(3995)]).then(__webpack_require__.bind(__webpack_require__, 3995)), {
    loadableGenerated: {
        modules: [
            "_app.js -> " + "../components/Layout/index"
        ]
    }
});









function MyApp({ Component , pageProps  }) {
    (0,external_react_.useEffect)(()=>{
        external_react_hotjar_namespaceObject.hotjar.initialize(3302739, 6);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                src: "https://maps.googleapis.com/maps/api/js?key=AIzaSyD15KqCiXEN2FKVzFgsO3Td-MyaeFotL84&libraries=places"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                src: "https://www.googletagmanager.com/gtag/js?id=G-GZSSE8GMGX",
                strategy: "afterInteractive"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "google-analytics",
                strategy: "afterInteractive",
                children: `
                   window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-GZSSE8GMGX');;
               `
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "p:domain_verify",
                        content: "74b83f2fc1f6b702815166d707bdcaad"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "google-site-verification",
                        content: "PoD0vRbbegsOcDDOZQHhcrbieW2ZPB616nsMmnWSKhA"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "canonical",
                        href:  false && 0
                    }, "canonical")
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
                    store: store_store,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.PersistGate, {
                        loading: null,
                        persistor: store_store,
                        children: ()=>/*#__PURE__*/ jsx_runtime_.jsx(Layout, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                                    ...pageProps
                                })
                            })
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 5931:
/***/ (() => {



/***/ }),

/***/ 861:
/***/ (() => {



/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 3318:
/***/ (() => {



/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap");

/***/ }),

/***/ 1937:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Button");

/***/ }),

/***/ 8582:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Dropdown");

/***/ }),

/***/ 9306:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,3573,5152,699], () => (__webpack_exec__(876)));
module.exports = __webpack_exports__;

})();