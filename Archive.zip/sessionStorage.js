// import * as React from 'react';
// import { ReactSession } from 'react-client-session';

// export const SessionSet = (sessionName, sessionValue) => {
//     ReactSession.setStoreType("localStorage");
//     ReactSession.set(sessionName, sessionValue);
// }

// export const SessionGet = (sessionName) => {
//     ReactSession.setStoreType("localStorage");
//     return ReactSession.get(sessionName);
// }

// export const SetSessionObject = (sessionName, sessionObject) => {
//     ReactSession.setStoreType("localStorage");
//     ReactSession.set(sessionName, sessionObject);
// }

// export const SessionGetObject = (sessionName) => {
//     ReactSession.setStoreType("localStorage");
//     return ReactSession.get(sessionName);
// }

// export const SessionRemoveObject = (sessionName) => {
//     ReactSession.setStoreType("localStorage");
//     return ReactSession.remove(sessionName);
// }