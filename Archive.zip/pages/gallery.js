function Gallery() {
    return (<>
        gallery
    </>);
}
export default Gallery;